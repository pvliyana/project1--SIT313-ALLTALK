﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForumProject1
{
    class Topics
    {
        public string Name { get; set; }
        public string Status { get; set; }
        public string ImageUrl { get; set; }
    }
}
