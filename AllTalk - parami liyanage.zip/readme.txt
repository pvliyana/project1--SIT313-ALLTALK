REFERENCES

lorempixel (2017). [image] Available at: http://lorempixel.com/100/100/people/1 [Accessed 30 Jul. 2017].
lorempixel (2017). [image] Available at: http://lorempixel.com/100/100/people/2 [Accessed 30 Jul. 2017].
lorempixel (2017). [image] Available at: http://lorempixel.com/100/100/people/3 [Accessed 30 Jul. 2017].
lorempixel (2017). [image] Available at: http://lorempixel.com/100/100/people/4 [Accessed 30 Jul. 2017].
lorempixel (2017). [image] Available at: http://lorempixel.com/100/100/people/5 [Accessed 30 Jul. 2017].
lorempixel (2017). [image] Available at: http://lorempixel.com/100/100/people/6 [Accessed 30 Jul. 2017].
lorempixel (2017). [image] Available at: http://lorempixel.com/100/100/people/7 [Accessed 30 Jul. 2017].
lorempixel (2017). [image] Available at: http://lorempixel.com/100/100/people/8 [Accessed 30 Jul. 2017].
lorempixel (2017). [image] Available at: http://lorempixel.com/100/100/people/9 [Accessed 2 Aug. 2017].

Anon, (2017). [image] Available at: https://www.oclc.org/content/marketing/publish/en_us/events/member-forums/after-party/_jcr_content/par/parsyscolumncontrol_1/col0/image.img.png/1486584912583.png [Accessed 30 Jul. 2017].
https://www.oclc.org/content/marketing/publish/en_us/events/member-forums/after-party/_jcr_content/par/parsyscolumncontrol_1/col0/image.img.png/1486584912583.png


link to github:

https://github.com/pvliyana/project1--SIT313-ALLTALK